using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;

namespace Deo.WebApp.Tests;

public class CounterPageTests : PageTest
{
    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        // TODO: setup
    }

    [SetUp]
    public void Setup()
    {
        // not needed for now
    }

    public override BrowserNewContextOptions ContextOptions()
    {
        // TODO: define options
    }

    // TODO: add tests

    [TearDown]
    public void TearDown()
    {
        // not needed for now
    }

    [OneTimeTearDown]
    public void OneTimeTearDown()
    {
        // not needed for now
    }
}
